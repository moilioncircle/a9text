function foo(){var njf1=njen(this,arguments);nj:while(1){switch(njf1.cp){case 0:
  njf1._a=doSomething1();njf1.pc(1,null,
  bar,[njf1._a]);case 1:with(njf1)if((rv1=f.apply(c,a))==NJSUS){return fh;}njf1._b=njf1.rv1;
  doSomething2(njf1._b);break nj;}}}
  
  
function bar(){var njf1=njen(this,arguments);nj:while(1){switch(njf1.cp){case 0:
  njf1._c=doSomething1();njf1.pc(1,null,
  foo,[njf1._c]);case 1:with(njf1)if((rv1=f.apply(c,a))==NJSUS){return fh;}
  doSomething2(d);break nj;}}}
