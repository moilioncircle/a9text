<?php

/*
    JavaScript Encryption Library
    Copyright (C) 2006  FarFarFar

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

header("Content-type: text/html; charset=utf-8");
echo '<?xml version="1.0"?'.'>'."\n";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US">
<head>
<title>JavaScript Encryption Library</title>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<meta name="keywords" content="JavaScript encryption library" />
<meta name="description" content="JavaScript encryption library that supports
MD5, SHA-1, SHA-256, Base64, XXTEA, and Blowfish encryption algorithms." />
<link rel="stylesheet" href="reset.css" type="text/css" />
<link rel="stylesheet" href="hash-graphic.style.php" type="text/css" />
<?php /*
<script type="text/javascript" src="lib/CommonFunctions.js"></script>
<script type="text/javascript" src="lib/Base64.js"></script>
<script type="text/javascript" src="lib/Bitwise.js"></script>
<script type="text/javascript" src="lib/Blowfish.js"></script>
<script type="text/javascript" src="lib/Error.js"></script>
<script type="text/javascript" src="lib/MD5.js"></script>
<script type="text/javascript" src="lib/SHA1.js"></script>
<script type="text/javascript" src="lib/SHA2.js"></script>
<script type="text/javascript" src="lib/Validator.js"></script>
<script type="text/javascript" src="lib/WrapperFunctions.js"></script>
<script type="text/javascript" src="lib/AbstractTEA.js"></script>
<script type="text/javascript" src="lib/TEA.js"></script>
<script type="text/javascript" src="lib/XTEA.js"></script>
<script type="text/javascript" src="lib/XXTEA.js"></script>
*/?>
<script type="text/javascript" src="packed.js"></script>

<script type="text/javascript"><!--

var messages;

function validateScript() {
	messages = new errorMessage();

	validate(messages);

	if (messages.printMessages() != "") {
		alert(messages.printMessages());
	}
}

validateScript();

function process(m, val){
	try {
		switch (m) {
		    case 1: val = hexToStr(val);
		    break;
		    case 2: val = Base64.decode(val);
		    break;
		}

		document.getElementById("MD5").value = md5(val);
		document.getElementById("SHA-1").value = sha1(val);
		document.getElementById("SHA-256").value = sha2(val);
	} catch (e) {
	    messages.addMessage(e);
	    alert(messages.printMessages());
	    processRaw("error");
	}
}

function processRaw(val){
	document.getElementById("MD5").value = val;
	document.getElementById("SHA-1").value = val;
	document.getElementById("SHA-256").value = val;
}

function encrypt(m, val, key) {
	try {
	    switch (m) {
	        case 'Blowfish':
	            var t = new Blowfish;
	            t.setKey(key);
	            //t.setKey(hexToStr(key));
	            //return strToHex(t.encrypt(hexToStr(val)));
	            return Base64.encode(t.encrypt(val));
	        case 'XXTEA':
				var t = new XXTEA;
				//return t.encrypt(hexToStr(val), hexToStr(key));
				return t.encrypt(val, key);
	        break;
	        case 'XTEA':
				var t = new XTEA;
				return t.encrypt(val, key);
	        break;
	        case 'TEA':
				var t = new TEA;
				return t.encrypt(val, key);
	        break;
	    }
	} catch (e) {
	    alert(e);
	    return "error";
	}
}

function decrypt(m, val, key) {
	try {
	    switch (m) {
	        case 'Blowfish':
	            var t = new Blowfish;
	            t.setKey(key);
	            //t.setKey(hexToStr(key));
	            //return strToHex(t.decrypt(hexToStr(val)));
	            return t.decrypt(Base64.decode(val));
	        case 'XXTEA':
				var t = new XXTEA;
				return t.decrypt(val, key);
				//return strToHex(t.decrypt(val, hexToStr(key)));
	        break;
	        case 'XTEA':
				var t = new XTEA;
				return t.decrypt(val, key);
	        break;
	        case 'TEA':
				var t = new TEA;
				return t.decrypt(val, key);
	        break;
	    }
	} catch (e) {
	    alert(e);
	    return "error";
	}
}

//--></script>
</head>
<body>

<div id="globalWrapper">
<h1>JavaScript Encryption Library</h1>

<noscript><p style="border:2px solid #888800;background-color:#ffffcc;padding:8px;font-family:Helvetica, Arial, sans-serif;width:524px;margin:0 auto;margin-bottom:64px;"><strong>Notice: </strong> Your browser does not support JavaScript. You are using the server sided version.</p></noscript>
<?php

$message = '';
$md5 = '';
$sha1 = '';
$sha256 = '';

function strhex($string) {

    $hex = '';
    $len = strlen($string);

    for ($i = 0; $i < $len; $i++) {

        $hex .= str_pad(dechex(ord($string[$i])), 2, 0, STR_PAD_LEFT);

    }

    return $hex;
}

function hexstr($hex) {
	$charHex = array('0','1','2','3','4','5','6','7','8','9','a','b','c','d','e','f');

	$str = '';
	
	$len = strlen($hex);
	
	if ($len % 2 == 1) $hex += "0";

	for ($i = 0; $i < $len; $i+=2) {
	    $i = array_search($hex[$i], $charHex);
	    $j = array_search($hex[$i+1], $charHex);
	    
	    if ($i === false || $j === false) {
	        throw new Exception("Hex invalid");
	    }
	    
	    $val = $i << 4 | $j;
	    $str .= chr($val);
	}
	
	return $str;
}

if (isset($_POST['message'])) {
	$message = $_POST['message'];
	
	try {
	    switch ($_POST['method']) {
	    	case 'hex':
	    		$_POST['message'] = hexstr($_POST['message']);
	    		break;
	   		case 'base64':
          		$_POST['message'] = preg_replace("/[^A-Za-z0-9\+\/\=]/s", "", $_POST['message']);
	    		$_POST['message'] = base64_decode($_POST['message']);
	    		if ($_POST['message'] === false) {
	    		    throw new Exception("Inproperly padded Base64 input");
	    		}
	    }

		require_once './php-sha-256.php';
		

		$md5 = md5($_POST['message']);
		$sha1 = sha1($_POST['message']);
		$sha256 = sha256($_POST['message']);
	} catch (Exception $e) {
	    $md5 = $e->getMessage();
		$sha1 = $e->getMessage();
		$sha256 = $e->getMessage();
	}
}

?>
<form id="hashBox" action="./" method="post" onsubmit="return false">

<fieldset>
<legend><span>Message Hasher</span></legend>

<label for="message">Message</label>
<input id="message" name="message" type="text" value="<?php echo htmlspecialchars($message); ?>" size="40" />

<div class="resultButtons">
<input type="image" src="image/hash-text.png" alt="Hash Text Encoded" onclick="process(0, document.getElementById('message').value)" name="method" value="text" />
<input type="image" src="image/hash-hex.png" alt="Hash Hex Encoded" onclick="process(1, document.getElementById('message').value)" name="method" value="hex"  />
<input type="image" src="image/hash-base64.png" alt="Hash Base64 Encoded" onclick="process(2, document.getElementById('message').value)" name="method" value="base64" />
</div>

<label for="MD5">MD5</label>
<input id="MD5" name="MD5" type="text" size="40" readonly="readonly" value="<?php
echo $md5; ?>" onclick="this.select()" />

<label for="SHA-1">SHA-1</label>
<input id="SHA-1" name="SHA-1" type="text" size="40" readonly="readonly" value="<?php
echo $sha1; ?>" onclick="this.select()" />

<label for="SHA-256">SHA-256</label>
<input id="SHA-256" name="SHA-256" type="text" size="40" readonly="readonly" value="<?php
echo $sha256; ?>" onclick="this.select()" />

</fieldset>

</form>


<form id="cipherBox" action="./" method="post" onsubmit="return false">

<fieldset>
<legend><span>Encrypt/Decrypt</span></legend>

<label for="key">Key</label> <input id="key" type="text" name="key" maxlength="32" value="sample key" />

<label for="plain">Message to encrypt</label>
<textarea name="plain" id="plain" rows="10" cols="60">Type in text to encrypt</textarea>


<div class="resultButtons">
<input type="image" src="image/Blowfish.png" alt="Blowfish Encrypt" value="Blowfish Encrypt" onclick="document.getElementById('enciphered').value=encrypt('Blowfish', document.getElementById('plain').value, document.getElementById('key').value)" />
<input type="image" src="image/XXTEA.png" alt="XXTEA Encrypt" value="XXTEA Encrypt" onclick="document.getElementById('enciphered').value=encrypt('XXTEA', document.getElementById('plain').value, document.getElementById('key').value)" />
<input type="image" src="image/XTEA.png" alt="XTEA Encrypt" value="XTEA Encrypt" onclick="document.getElementById('enciphered').value=encrypt('XTEA', document.getElementById('plain').value, document.getElementById('key').value)" />
<input type="image" src="image/TEA.png" alt="TEA Encrypt" value="TEA Encrypt" onclick="document.getElementById('enciphered').value=encrypt('TEA', document.getElementById('plain').value, document.getElementById('key').value)" />
</div>

<label for="enciphered">Encrypted</label>
<textarea name="enciphered" id="enciphered" rows="10" cols="60"></textarea>

<div class="resultButtons">
<input type="image" src="image/Blowfish.png" value="Blowfish Decrypt" onclick="document.getElementById('deciphered').value=decrypt('Blowfish', document.getElementById('enciphered').value, document.getElementById('key').value)" />
<input type="image" src="image/XXTEA.png" value="XXTEA Decrypt" onclick="document.getElementById('deciphered').value=decrypt('XXTEA', document.getElementById('enciphered').value, document.getElementById('key').value)" />
<input type="image" src="image/XTEA.png" value="XTEA Decrypt" onclick="document.getElementById('deciphered').value=decrypt('XTEA', document.getElementById('enciphered').value, document.getElementById('key').value)" />
<input type="image" src="image/TEA.png" value="TEA Decrypt" onclick="document.getElementById('deciphered').value=decrypt('TEA', document.getElementById('enciphered').value, document.getElementById('key').value)" />
</div>

<label for="deciphered">Decrypted</label>
<textarea name="deciphered" id="deciphered" rows="10" readonly="readonly" cols="60"></textarea>

</fieldset>

</form>

<p style="border:2px solid #888800;background-color:#ffffcc;padding:8px;font-family:Helvetica, Arial, sans-serif;width:524px;margin:0 auto;margin-bottom:64px;"><strong>Notice: </strong> Our XXTEA version  is accurate, but our blowfish implementation is inaccurate.</p>

<p id="other">Our <a href="index2.html">Old version</a> is available.</p>

<h2>Download</h2>
<p><a href="encrypt.zip">encrypt.zip</a></p>
<p><a href="encrypt.js">encrypt.js</a></p>

<h2>Links</h2>
<ul>
<li>JavaScript<ul>
<li><a href="http://anmar.eu.org/projects/jssha2/">Another JavaScript SHA-2</a></li>
<li><a href="http://pajhome.org.uk/crypt/md5/index.html">JavaScript MD4, MD5, SHA-1</a></li>
<li><a href="http://www.movable-type.co.uk/scripts/SHA-1.html">Another JavaScript SHA-1</a></li>
<li><a href="http://www.movable-type.co.uk/scripts/TEAblock.html">Another JavaScript XXTEA</a></li>
<li><a href="http://www-cse.ucsd.edu/~fritz/rijndael.html">JavaScript Rijndael</a></li>
<li><a href="http://www.fourmilab.ch/javascrypt/javascrypt.html">JavaScript Rijndael</a></li>
<li><a href="http://www.enetplanet.com/enc/">JavaScript 256-bit Rijndael</a></li>
<li><a href="http://home.foni.net/~hanewin/encrypt/aes/aes.htm">JavaScript Rijndael</a></li>
<li><a href="http://www.hanewin.de/encrypt/main.htm">JavaScript RSA and Rijndael</a></li>
<li><a href="http://russ.hn.org/twofish/">JavaScript Twofish</a></li>
<li><a href="http://aam.ugpl.de/node/1060">Another JavaScript Blowfish</a></li>
</ul>

<li>Open Source Programs<ul>
<li><a href="http://www.eskimo.com/~weidai/cryptlib.html">Crypto++</a> - C++ crypto library that supports many cryptographic schemes.</li>
<li><a href="http://botan.randombit.net/">Botan</a> - C++ crypto library that supports many cryptographic schemes.</li>
<li><a href="http://www.gnu.org/software/gnu-crypto/">GNUCrypto</a> - Java crypto library that supports many cryptographic schemes.</li>
<li><a href="http://www.jonelo.de/java/jacksum/">Jacksum</a> - Java library that supports many different hashes</li>
<li><a href="http://www.cr0.net:8040/code/crypto/">Optimized versions of AES, RC4, 3DES, MD5, SHA-1, and SHA-256 written in C.</a></li>
</ul>
<p id="logos">
    <a href="http://validator.w3.org/check?uri=referer"><img
        src="http://www.w3.org/Icons/valid-xhtml10-blue"
        alt="Valid XHTML 1.0 Strict" height="31" width="88" /></a>
<a href="http://jigsaw.w3.org/css-validator/">
    <img style="border:0;width:88px;height:31px"
        src="http://jigsaw.w3.org/css-validator/images/vcss-blue"
        alt="Valid CSS!" />
</a>
<a href="http://www.w3.org/WAI/WCAG1A-Conformance">
    <img style="border:0;width:88px;height:31px"
        src="http://www.w3.org/WAI/wcag1A-blue"
        alt="Valid" /></a></p>

<p id="footer" style="margin-bottom:128px;">Copyright &copy; FarFarFar</p>
</div>

</body>
</html>
