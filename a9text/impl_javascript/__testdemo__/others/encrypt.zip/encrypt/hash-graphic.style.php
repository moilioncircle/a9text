<?php

/*
    JavaScript Encryption Library
    Copyright (C) 2006  FarFarFar

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

header("Content-type:text/css");
?>

body {
	background:#ffffff;
}

<?php
$width = 576;
$height = 252;
$padding_top = 48;

$height_2 = 800;

$row_bottom = 8;
$margin_left = 32;
$margin_right = 32;

$label_inner_width = 100;

$inner_padding_v = 2;
$inner_padding_h = 4;

$input_border = 1;

//$height = $padding_top + ($inner_padding_v +
//	$input_border) * 2 + $row_bottom;

?>

#globalWrapper {
	width:<?php echo $width; ?>px;
	margin:0 auto
}

body {
	background:#ffffff;
	margin-top:30px;
}

strong {
	font-weight:bold;
}

#hashBox,
#cipherBox {
	background:#f3f3f3;
	padding-top:<?php echo $padding_top ?>px;
	margin:0 auto;
	margin-bottom:32px;
}

#hashBox {
	background-image:url("image/hashBoxBlank.png");
	width:<?php echo $width ?>px;
	height:<?php echo $height-$padding_top ?>px;
}

#cipherBox {
	background-image:url("image/cipherBox.png");
	width:<?php echo $width ?>px;
	height:<?php echo $height_2-$padding_top ?>px;
}

fieldset {
	position:relative !important;
	display:block !important;
}

legend span {
	font-size:130%;
	font-weight:bold;
	position:absolute;
	display:block;
	width:100%;
	text-align:center;
	top:-30px;
	font-family:Tahoma, Sans;
}

label {
	font-family:Verdana, Geneva, sans-serif;
	color:#333333;
	margin-bottom:<?php echo $row_bottom ?>px;
	margin-left:<?php echo $margin_left ?>px;
	text-align:left;
	float:left;
	font-size:100%;
	clear:left;
	width:<?php echo $label_inner_width + $input_border ?>px;
	padding:<?php echo ($inner_padding_v + $input_border) ?>px
		<?php echo ($inner_padding_h + $input_border) ?>px
		<?php echo ($inner_padding_v + $input_border) ?>px
		<?php echo ($inner_padding_h + $input_border) ?>px;
}

<?php
$label_width = $margin_left + $label_inner_width + ($inner_padding_v + $input_border) * 2;
?>

input[type=text],
textarea {
	margin-bottom:<?php echo $row_bottom ?>px;
	margin-right:<?php echo $margin_right ?>px;
	float:left;
	border:<?php echo $input_border ?>px solid #808080;
	padding:<?php echo $inner_padding_v ?>px <?php echo $input_border ?>px;
	width:<?php echo
    	$width - $label_width -
		($inner_padding_h + $input_border) * 2 -
		$margin_right;
	?>px;
}

input[type=text][readonly],
textarea[readonly] {
	background-color:#f0f0ff;
}

input[type=image] {
	font-family:Arial Black, Geneva, sans-serif;
}

.resultButtons {
	margin-bottom:<?php echo $row_bottom ?>px;
	clear:both;
	text-align:center
}

#logos {
	text-align:center;
	margin-bottom:30px;
}

#other {
	text-align:center;
	margin-bottom:30px;
}

#footer {
	text-align:center;
	font-size:90%;
	font-family:Verdana, Geneva, sans-serif;
	color:#404040;
}

h1 {
	font-size:150%;
	text-align:center;
	margin-bottom:64px;
}

h2 {
	font-size:130%;
}

ul li {
	line-height:1.4em;
	margin-left:1em
}

<?php /*
#encryptForm legend {
	padding:4px;
	margin-bottom:24px;
	font-style:italic;
	font-family:Georgia,'Trebucher MS', Helvetica, Arial, Sans-serif;
	font-size:24px;
}

#hashForm {
  background:url("image/hashBoxRounded.png") no-repeat  bottom;
  height:240px;
  width:100%;
}

#cipherForm {
	background:url("image/cipherGradient.png") no-repeat right bottom;
  height:880px;
  width:100%;
}


#encryptForm .outputLine {
	padding:4px 0;
	text-align:center;
	clear:both;
}










#encryptForm label {
	width:100px;
	display:block;
	padding:2px 0;
	float:left;
	margin:0;
	color:#444444;
	font-family:Tahoma, Sans;
	font-weight:bold;
}

#encryptForm label[for=hashInput] {
	width:150px;
}

#encryptForm input,
#encryptForm textarea {
	padding:2px 4px;
	border:1px solid #888888;
	font-size:14px;
}

#encryptForm input[type=text] {
	width:452px;
	float:left;
}

#encryptForm textarea {
	width:552px;
	height:200px;
}

#hashInput {
	width:400px;
	float:left;
}

#encryptForm #hashForm input[type=text][readonly],
#encryptForm textarea[readonly] {
	background-color:#ffffcc;
	font-size:12px;
}

#resultsImage {
 background:url("image/results-gradient.png") no-repeat center;
 width:556px;
 height:32px;
 margin:0;
 padding:0;
}

#encryptForm input[type=button] {
	margin-top:2px;
	font-weight:bold;
	color:#ffffff;
	font-size:12px;
	padding:1px 4px;
	background-color:#66aa44;
	font-family:Tahoma, Sans;
}

#encryptForm .buttonRow input[type=button] {
	margin:2px 1px;
}

#encryptForm label[for=key] {
	width:100px;
}

#encryptForm #key {
	width:200px;
}

#encryptForm #cipherForm label {
	width:100%;
	margin:2px 0;
}*/?>
